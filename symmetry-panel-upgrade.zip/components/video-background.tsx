'use client'

import { useRef, useEffect, forwardRef, useImperativeHandle } from 'react'

export type VideoBackgroundRef = {
  play: () => void
  pause: () => void
  toggleMute: () => void
  isMuted: () => boolean
  isPaused: () => boolean
}

interface VideoBackgroundProps {
  src?: string
  onLoadedData?: () => void
}

const VideoBackground = forwardRef<VideoBackgroundRef, VideoBackgroundProps>(
  function VideoBackground({ src, onLoadedData }, ref) {
    const videoRef = useRef<HTMLVideoElement>(null)

    useImperativeHandle(ref, () => ({
      play: () => {
        videoRef.current?.play()
      },
      pause: () => {
        videoRef.current?.pause()
      },
      toggleMute: () => {
        if (videoRef.current) {
          videoRef.current.muted = !videoRef.current.muted
        }
      },
      isMuted: () => {
        return videoRef.current?.muted ?? true
      },
      isPaused: () => {
        return videoRef.current?.paused ?? false
      },
    }))

    useEffect(() => {
      if (videoRef.current) {
        videoRef.current.play().catch(() => {
          // Autoplay might be blocked
        })
      }
    }, [src])

    // Default demo video - a beautiful looping video
    const videoSrc = src || 'https://assets.mixkit.co/videos/4793/4793-720.mp4'

    return (
      <div className="fixed inset-0 z-0 overflow-hidden bg-background">
        <video
          ref={videoRef}
          className="absolute h-full w-full object-cover"
          src={videoSrc}
          autoPlay
          loop
          muted
          playsInline
          onLoadedData={onLoadedData}
        />
        {/* Subtle vignette overlay */}
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_0%,rgba(0,0,0,0.3)_100%)]" />
      </div>
    )
  }
)

export default VideoBackground
