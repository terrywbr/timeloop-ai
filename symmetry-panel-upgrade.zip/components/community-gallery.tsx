'use client'

import { useRef, useCallback, useEffect, useState } from 'react'
import { ChevronLeft, ChevronDown, ChevronUp, ImageIcon, ShoppingCart } from 'lucide-react'
import { useLanguage } from '@/lib/language-context'

interface CommunityGalleryProps {
  isExpanded: boolean
  onExpandedChange: (expanded: boolean) => void
}

type Rarity = 'legendary' | 'rare' | 'common'

// Mock NFT data - 3x7 grid (21 items)
const nftItems: {
  id: string
  thumbnail: string
  price: string
  rarity: Rarity
}[] = [
  { id: '001', thumbnail: 'https://images.unsplash.com/photo-1634017839464-5c339bbe3c35?w=150&h=150&fit=crop', price: '0.5', rarity: 'legendary' },
  { id: '002', thumbnail: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150&h=150&fit=crop', price: '0.8', rarity: 'rare' },
  { id: '003', thumbnail: 'https://images.unsplash.com/photo-1620641788421-7a1c342ea42e?w=150&h=150&fit=crop', price: '1.2', rarity: 'legendary' },
  { id: '004', thumbnail: 'https://images.unsplash.com/photo-1558591710-4b4a1ae0f04d?w=150&h=150&fit=crop', price: '0.6', rarity: 'common' },
  { id: '005', thumbnail: 'https://images.unsplash.com/photo-1614850523459-c2f4c699c52e?w=150&h=150&fit=crop', price: '0.9', rarity: 'rare' },
  { id: '006', thumbnail: 'https://images.unsplash.com/photo-1549490349-8643362247b5?w=150&h=150&fit=crop', price: '0.7', rarity: 'common' },
  { id: '007', thumbnail: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=150&h=150&fit=crop', price: '1.5', rarity: 'legendary' },
  { id: '008', thumbnail: 'https://images.unsplash.com/photo-1518640467707-6811f4a6ab73?w=150&h=150&fit=crop', price: '0.4', rarity: 'common' },
  { id: '009', thumbnail: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=150&h=150&fit=crop', price: '2.1', rarity: 'legendary' },
  { id: '010', thumbnail: 'https://images.unsplash.com/photo-1557672172-298e090bd0f1?w=150&h=150&fit=crop', price: '0.3', rarity: 'common' },
  { id: '011', thumbnail: 'https://images.unsplash.com/photo-1604076913837-52ab5629fba9?w=150&h=150&fit=crop', price: '1.8', rarity: 'rare' },
  { id: '012', thumbnail: 'https://images.unsplash.com/photo-1567095761054-7a02e69e5c43?w=150&h=150&fit=crop', price: '0.5', rarity: 'common' },
  { id: '013', thumbnail: 'https://images.unsplash.com/photo-1550859492-d5da9d8e45f3?w=150&h=150&fit=crop', price: '3.2', rarity: 'legendary' },
  { id: '014', thumbnail: 'https://images.unsplash.com/photo-1541701494587-cb58502866ab?w=150&h=150&fit=crop', price: '0.9', rarity: 'rare' },
  { id: '015', thumbnail: 'https://images.unsplash.com/photo-1509114397022-ed747cca3f65?w=150&h=150&fit=crop', price: '0.4', rarity: 'common' },
  { id: '016', thumbnail: 'https://images.unsplash.com/photo-1563089145-599997674d42?w=150&h=150&fit=crop', price: '1.1', rarity: 'rare' },
  { id: '017', thumbnail: 'https://images.unsplash.com/photo-1618172193622-ae2d025f4032?w=150&h=150&fit=crop', price: '0.6', rarity: 'common' },
  { id: '018', thumbnail: 'https://images.unsplash.com/photo-1604871000636-074fa5117945?w=150&h=150&fit=crop', price: '2.5', rarity: 'legendary' },
  { id: '019', thumbnail: 'https://images.unsplash.com/photo-1617791160505-6f00504e3519?w=150&h=150&fit=crop', price: '0.7', rarity: 'rare' },
  { id: '020', thumbnail: 'https://images.unsplash.com/photo-1614730321146-b6fa6a46bcb4?w=150&h=150&fit=crop', price: '0.3', rarity: 'common' },
  { id: '021', thumbnail: 'https://images.unsplash.com/photo-1578301978693-85fa9c0320b9?w=150&h=150&fit=crop', price: '1.9', rarity: 'legendary' },
]

export default function CommunityGallery({ isExpanded, onExpandedChange }: CommunityGalleryProps) {
  const panelRef = useRef<HTMLDivElement>(null)
  const timeoutRef = useRef<NodeJS.Timeout | null>(null)
  const [isAdExpanded, setIsAdExpanded] = useState(false)
  const { t } = useLanguage()

  const startCollapseTimer = useCallback(() => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current)
    }
    timeoutRef.current = setTimeout(() => {
      onExpandedChange(false)
    }, 3000)
  }, [onExpandedChange])

  const handleMouseEnter = () => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current)
    }
    onExpandedChange(true)
  }

  const handleMouseLeave = () => {
    startCollapseTimer()
  }

  const handleTouchStart = () => {
    if (!isExpanded) {
      onExpandedChange(true)
    }
  }

  useEffect(() => {
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current)
      }
    }
  }, [])

  return (
    <div
      ref={panelRef}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      onTouchStart={handleTouchStart}
      className={`fixed right-0 top-0 z-50 hidden h-full transition-all duration-500 ease-[cubic-bezier(0.4,0,0.2,1)] md:block ${
        isExpanded ? 'w-[280px]' : 'w-[40px]'
      }`}
    >
      {/* Glassmorphism background */}
      <div
        className={`glass absolute inset-0 border-l border-foreground/10 transition-all duration-500 ${
          isExpanded ? 'bg-popover/70' : 'bg-popover/30'
        }`}
      />

      {/* Collapse indicator when collapsed */}
      {!isExpanded && (
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <ChevronLeft className="h-5 w-5 animate-pulse text-foreground/50" />
        </div>
      )}

      {/* Expanded content */}
      <div
        className={`no-scrollbar relative flex h-full flex-col overflow-y-auto transition-opacity duration-300 ${
          isExpanded ? 'opacity-100' : 'pointer-events-none opacity-0'
        }`}
      >
        {/* Header */}
        <div className="sticky top-0 z-10 glass bg-popover/80 p-3 border-b border-foreground/10">
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-accent/20">
              <ImageIcon className="h-3.5 w-3.5 text-accent" />
            </div>
            <h2 className="text-sm font-semibold text-foreground">{t.gallery.title}</h2>
          </div>
        </div>

        {/* NFT Grid - 3 columns (9-grid) */}
        <div className="grid grid-cols-3 gap-1.5 p-2">
          {nftItems.map((item) => (
            <NFTCardMini key={item.id} item={item} />
          ))}
        </div>

        {/* Advertisement - Collapsible dropdown */}
        <div className="sticky bottom-0 z-10 p-2">
          <div className="glass overflow-hidden rounded-xl border border-foreground/10 bg-popover/50">
            {/* Toggle button */}
            <button
              onClick={() => setIsAdExpanded(!isAdExpanded)}
              className="flex w-full items-center justify-between px-3 py-2 text-xs text-muted-foreground/60 transition-all hover:bg-foreground/5"
            >
              <span>Sponsored</span>
              {isAdExpanded ? (
                <ChevronDown className="h-3 w-3" />
              ) : (
                <ChevronUp className="h-3 w-3" />
              )}
            </button>
            
            {/* Collapsible content */}
            <div
              className={`overflow-hidden transition-all duration-300 ease-out ${
                isAdExpanded ? 'max-h-[150px] opacity-100' : 'max-h-0 opacity-0'
              }`}
            >
              <div className="flex h-[120px] items-center justify-center border-t border-foreground/5 px-3 pb-3">
                <span className="text-xs text-muted-foreground/40">Sponsored Content</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

interface NFTCardMiniProps {
  item: {
    id: string
    thumbnail: string
    price: string
    rarity: Rarity
  }
}

const rarityBorders: Record<Rarity, string> = {
  legendary: 'ring-1 ring-amber-500/50',
  rare: 'ring-1 ring-purple-500/50',
  common: 'ring-1 ring-foreground/10',
}

function NFTCardMini({ item }: NFTCardMiniProps) {
  return (
    <div className={`group relative aspect-square cursor-pointer overflow-hidden rounded-md ${rarityBorders[item.rarity]} transition-all duration-200 hover:scale-105 hover:ring-2`}>
      {/* Static thumbnail - no animations for performance */}
      <img
        src={item.thumbnail}
        alt={`NFT #${item.id}`}
        className="h-full w-full object-cover"
        crossOrigin="anonymous"
        loading="lazy"
      />
      
      {/* Always visible: ID badge */}
      <div className="absolute left-0.5 top-0.5 rounded-sm bg-black/60 px-1 py-px text-[8px] font-mono text-white/90">
        #{item.id}
      </div>
      
      {/* Hover overlay with price */}
      <div className="absolute inset-0 flex items-end justify-center bg-gradient-to-t from-black/80 to-transparent opacity-0 transition-opacity duration-200 group-hover:opacity-100">
        <div className="mb-1 flex items-center gap-1 rounded-full bg-black/50 px-1.5 py-0.5 backdrop-blur-sm">
          <span className="text-[8px] font-medium text-accent">{item.price} ETH</span>
          <ShoppingCart className="h-2.5 w-2.5 text-white/80" />
        </div>
      </div>
    </div>
  )
}
