export type Language = 'en' | 'zh-CN' | 'zh-TW' | 'ja' | 'ko' | 'es' | 'fr' | 'de'

export const languages: { code: Language; name: string; nativeName: string }[] = [
  { code: 'en', name: 'English', nativeName: 'English' },
  { code: 'zh-CN', name: 'Chinese (Simplified)', nativeName: '简体中文' },
  { code: 'zh-TW', name: 'Chinese (Traditional)', nativeName: '繁體中文' },
  { code: 'ja', name: 'Japanese', nativeName: '日本語' },
  { code: 'ko', name: 'Korean', nativeName: '한국어' },
  { code: 'es', name: 'Spanish', nativeName: 'Español' },
  { code: 'fr', name: 'French', nativeName: 'Français' },
  { code: 'de', name: 'German', nativeName: 'Deutsch' },
]

export const translations: Record<Language, {
  title: string
  inputPlaceholder: string
  sceneLabel: string
  generateButton: string
  generating: string
  scenes: {
    cyberpunk: string
    nature: string
    space: string
    ocean: string
    city: string
    desert: string
  }
  controls: {
    play: string
    pause: string
    volume: string
    mute: string
    unmute: string
    download: string
    settings: string
    fullscreen: string
    exitFullscreen: string
  }
  membership: {
    free: string
    vip: string
    perMonth: string
  }
  language: string
  gallery: {
    title: string
    rentBuy: string
    creator: string
    featured: string
    trending: string
  }
  music: {
    title: string
    channels: {
      lofiChill: string
      synthNight: string
      ambientForest: string
    }
    favorites: string
    alreadyFavorited: string
    noFavorites: string
    volume: string
  }
  myScenes: {
    title: string
    save: string
    namePlaceholder: string
    noScenes: string
    cancel: string
    confirm: string
  }
  nft: {
    legendary: string
    rare: string
    common: string
  }
}> = {
  en: {
    title: 'Time Loop AI',
    inputPlaceholder: 'Describe your scene...',
    sceneLabel: 'Scene Type',
    generateButton: 'Generate',
    generating: 'Generating...',
    scenes: {
      cyberpunk: 'Cyberpunk City',
      nature: 'Nature Landscape',
      space: 'Outer Space',
      ocean: 'Ocean Waves',
      city: 'Modern City',
      desert: 'Desert Dunes',
    },
    controls: {
      play: 'Play',
      pause: 'Pause',
      volume: 'Volume',
      mute: 'Mute',
      unmute: 'Unmute',
      download: 'Download',
      settings: 'Settings',
      fullscreen: 'Fullscreen',
      exitFullscreen: 'Exit Fullscreen',
    },
    membership: {
      free: 'Free: 5 generations/month',
      vip: 'VIP $5/month: 30 generations',
      perMonth: '/month',
    },
    language: 'Language',
    gallery: {
      title: 'Community Gallery',
      rentBuy: 'Rent/Buy',
      creator: 'Creator',
      featured: 'Featured',
      trending: 'Trending',
    },
    music: {
      title: 'Ambient Music',
      channels: {
        lofiChill: 'Lofi Study',
        synthNight: 'Synthwave',
        ambientForest: 'Ambient Rain',
      },
      favorites: 'My Favorites',
      alreadyFavorited: 'Already in favorites',
      noFavorites: 'No favorites yet',
      volume: 'Volume',
    },
    myScenes: {
      title: 'My Scenes',
      save: 'Save Current',
      namePlaceholder: 'Scene name...',
      noScenes: 'No saved scenes',
      cancel: 'Cancel',
      confirm: 'Save',
    },
    nft: {
      legendary: 'Legendary',
      rare: 'Rare',
      common: 'Common',
    },
  },
  'zh-CN': {
    title: 'Time Loop AI',
    inputPlaceholder: '描述你想要的场景...',
    sceneLabel: '场景类型',
    generateButton: '生成',
    generating: '生成中...',
    scenes: {
      cyberpunk: '赛博朋克城市',
      nature: '自然风景',
      space: '外太空',
      ocean: '海浪',
      city: '现代都市',
      desert: '沙漠沙丘',
    },
    controls: {
      play: '播放',
      pause: '暂停',
      volume: '音量',
      mute: '静音',
      unmute: '取消静音',
      download: '下载',
      settings: '设置',
      fullscreen: '全屏',
      exitFullscreen: '退出全屏',
    },
    membership: {
      free: '免费：5次/月',
      vip: 'VIP $5/月：30次/月',
      perMonth: '/月',
    },
    language: '语言',
    gallery: {
      title: '社区画廊',
      rentBuy: '租/购',
      creator: '创作者',
      featured: '精选',
      trending: '热门',
    },
    music: {
      title: '氛围音乐',
      channels: {
        lofiChill: '深夜书房',
        synthNight: '赛博微光',
        ambientForest: '雨天冥想',
      },
      favorites: '我的收藏',
      alreadyFavorited: '已在收藏中',
      noFavorites: '暂无收藏',
      volume: '音量',
    },
    myScenes: {
      title: '我的情境',
      save: '保存当前',
      namePlaceholder: '情境名称...',
      noScenes: '暂无保存的情境',
      cancel: '取消',
      confirm: '保存',
    },
    nft: {
      legendary: '传奇',
      rare: '稀有',
      common: '普通',
    },
  },
  'zh-TW': {
    title: 'Time Loop AI',
    inputPlaceholder: '描述你想要的場景...',
    sceneLabel: '場景類型',
    generateButton: '生成',
    generating: '生成中...',
    scenes: {
      cyberpunk: '賽博朋克城市',
      nature: '自然風景',
      space: '外太空',
      ocean: '海浪',
      city: '現代都市',
      desert: '沙漠沙丘',
    },
    controls: {
      play: '播放',
      pause: '暫停',
      volume: '音量',
      mute: '靜音',
      unmute: '取消靜音',
      download: '下載',
      settings: '設定',
      fullscreen: '全螢幕',
      exitFullscreen: '退出全螢幕',
    },
    membership: {
      free: '免費：5次/月',
      vip: 'VIP $5/月：30次/月',
      perMonth: '/月',
    },
    language: '語言',
    gallery: {
      title: '社區畫廊',
      rentBuy: '租/購',
      creator: '創作者',
      featured: '精選',
      trending: '熱門',
    },
    music: {
      title: '氛圍音樂',
      channels: {
        lofiChill: '深夜書房',
        synthNight: '賽博微光',
        ambientForest: '雨天冥想',
      },
      favorites: '我的收藏',
      alreadyFavorited: '已在收藏中',
      noFavorites: '暫無收藏',
      volume: '音量',
    },
    myScenes: {
      title: '我的情境',
      save: '保存當前',
      namePlaceholder: '情境名稱...',
      noScenes: '暫無保存的情境',
      cancel: '取消',
      confirm: '保存',
    },
    nft: {
      legendary: '傳奇',
      rare: '稀有',
      common: '普通',
    },
  },
  ja: {
    title: 'Time Loop AI',
    inputPlaceholder: 'シーンを説明してください...',
    sceneLabel: 'シーンタイプ',
    generateButton: '生成',
    generating: '生成中...',
    scenes: {
      cyberpunk: 'サイバーパンク都市',
      nature: '自然風景',
      space: '宇宙空間',
      ocean: '海の波',
      city: '現代都市',
      desert: '砂漠の砂丘',
    },
    controls: {
      play: '再生',
      pause: '一時停止',
      volume: '音量',
      mute: 'ミュート',
      unmute: 'ミュート解除',
      download: 'ダウンロード',
      settings: '設定',
      fullscreen: 'フルスクリーン',
      exitFullscreen: 'フルスクリーン解除',
    },
    membership: {
      free: '無料：月5回',
      vip: 'VIP $5/月：月30回',
      perMonth: '/月',
    },
    language: '言語',
    gallery: {
      title: 'コミュニティギャラリー',
      rentBuy: 'レンタル/購入',
      creator: 'クリエイター',
      featured: '注目',
      trending: 'トレンド',
    },
    music: {
      title: 'アンビエント音楽',
      channels: {
        lofiChill: '深夜の書斎',
        synthNight: 'シンセウェーブ',
        ambientForest: '雨の瞑想',
      },
      favorites: 'お気に入り',
      alreadyFavorited: '既にお気に入りです',
      noFavorites: 'お気に入りはありません',
      volume: '音量',
    },
    myScenes: {
      title: 'マイシーン',
      save: '現在を保存',
      namePlaceholder: 'シーン名...',
      noScenes: '保存されたシーンはありません',
      cancel: 'キャンセル',
      confirm: '保存',
    },
    nft: {
      legendary: 'レジェンダリー',
      rare: 'レア',
      common: 'コモン',
    },
  },
  ko: {
    title: 'Time Loop AI',
    inputPlaceholder: '원하는 장면을 설명하세요...',
    sceneLabel: '장면 유형',
    generateButton: '생성',
    generating: '생성 중...',
    scenes: {
      cyberpunk: '사이버펑크 도시',
      nature: '자연 풍경',
      space: '우주 공간',
      ocean: '바다 파도',
      city: '현대 도시',
      desert: '사막 모래언덕',
    },
    controls: {
      play: '재생',
      pause: '일시정지',
      volume: '볼륨',
      mute: '음소거',
      unmute: '음소거 해제',
      download: '���운로드',
      settings: '설정',
      fullscreen: '전체 화면',
      exitFullscreen: '전체 화면 종료',
    },
    membership: {
      free: '무료: 월 5회',
      vip: 'VIP $5/월: 월 30회',
      perMonth: '/월',
    },
    language: '언어',
    gallery: {
      title: '커뮤니티 갤러리',
      rentBuy: '대여/구매',
      creator: '크리에이터',
      featured: '추천',
      trending: '인기',
    },
    music: {
      title: '앰비언트 음악',
      channels: {
        lofiChill: '심야 서재',
        synthNight: '신스웨이브',
        ambientForest: '빗소리 명상',
      },
      favorites: '즐겨찾기',
      alreadyFavorited: '이미 즐겨찾기에 있습니다',
      noFavorites: '즐겨찾기가 없습니다',
      volume: '볼륨',
    },
    myScenes: {
      title: '내 장면',
      save: '현재 저장',
      namePlaceholder: '장면 이름...',
      noScenes: '저장된 장면이 없습니다',
      cancel: '취소',
      confirm: '저장',
    },
    nft: {
      legendary: '레전더리',
      rare: '레어',
      common: '커먼',
    },
  },
  es: {
    title: 'Time Loop AI',
    inputPlaceholder: 'Describe tu escena...',
    sceneLabel: 'Tipo de escena',
    generateButton: 'Generar',
    generating: 'Generando...',
    scenes: {
      cyberpunk: 'Ciudad Cyberpunk',
      nature: 'Paisaje Natural',
      space: 'Espacio Exterior',
      ocean: 'Olas del Océano',
      city: 'Ciudad Moderna',
      desert: 'Dunas del Desierto',
    },
    controls: {
      play: 'Reproducir',
      pause: 'Pausar',
      volume: 'Volumen',
      mute: 'Silenciar',
      unmute: 'Activar sonido',
      download: 'Descargar',
      settings: 'Ajustes',
      fullscreen: 'Pantalla completa',
      exitFullscreen: 'Salir de pantalla completa',
    },
    membership: {
      free: 'Gratis: 5 generaciones/mes',
      vip: 'VIP $5/mes: 30 generaciones',
      perMonth: '/mes',
    },
    language: 'Idioma',
    gallery: {
      title: 'Galería Comunitaria',
      rentBuy: 'Alquilar/Comprar',
      creator: 'Creador',
      featured: 'Destacado',
      trending: 'Tendencia',
    },
    music: {
      title: 'Música Ambiental',
      channels: {
        lofiChill: 'Estudio Nocturno',
        synthNight: 'Synthwave',
        ambientForest: 'Lluvia Meditativa',
      },
      favorites: 'Mis Favoritos',
      alreadyFavorited: 'Ya está en favoritos',
      noFavorites: 'Sin favoritos',
      volume: 'Volumen',
    },
    myScenes: {
      title: 'Mis Escenas',
      save: 'Guardar actual',
      namePlaceholder: 'Nombre de escena...',
      noScenes: 'Sin escenas guardadas',
      cancel: 'Cancelar',
      confirm: 'Guardar',
    },
    nft: {
      legendary: 'Legendario',
      rare: 'Raro',
      common: 'Común',
    },
  },
  fr: {
    title: 'Time Loop AI',
    inputPlaceholder: 'Décrivez votre scène...',
    sceneLabel: 'Type de scène',
    generateButton: 'Générer',
    generating: 'Génération...',
    scenes: {
      cyberpunk: 'Ville Cyberpunk',
      nature: 'Paysage Naturel',
      space: 'Espace Extra-atmosphérique',
      ocean: 'Vagues de l\'Océan',
      city: 'Ville Moderne',
      desert: 'Dunes du Désert',
    },
    controls: {
      play: 'Lecture',
      pause: 'Pause',
      volume: 'Volume',
      mute: 'Muet',
      unmute: 'Son activé',
      download: 'Télécharger',
      settings: 'Paramètres',
      fullscreen: 'Plein écran',
      exitFullscreen: 'Quitter le plein écran',
    },
    membership: {
      free: 'Gratuit: 5 générations/mois',
      vip: 'VIP 5$/mois: 30 générations',
      perMonth: '/mois',
    },
    language: 'Langue',
    gallery: {
      title: 'Galerie Communautaire',
      rentBuy: 'Louer/Acheter',
      creator: 'Créateur',
      featured: 'En vedette',
      trending: 'Tendances',
    },
    music: {
      title: 'Musique Ambiante',
      channels: {
        lofiChill: 'Bureau de Nuit',
        synthNight: 'Synthwave',
        ambientForest: 'Pluie Méditative',
      },
      favorites: 'Mes Favoris',
      alreadyFavorited: 'Déjà dans les favoris',
      noFavorites: 'Pas de favoris',
      volume: 'Volume',
    },
    myScenes: {
      title: 'Mes Scènes',
      save: 'Enregistrer actuel',
      namePlaceholder: 'Nom de scène...',
      noScenes: 'Aucune scène enregistrée',
      cancel: 'Annuler',
      confirm: 'Enregistrer',
    },
    nft: {
      legendary: 'Légendaire',
      rare: 'Rare',
      common: 'Commun',
    },
  },
  de: {
    title: 'Time Loop AI',
    inputPlaceholder: 'Beschreiben Sie Ihre Szene...',
    sceneLabel: 'Szenentyp',
    generateButton: 'Generieren',
    generating: 'Generierung...',
    scenes: {
      cyberpunk: 'Cyberpunk-Stadt',
      nature: 'Naturlandschaft',
      space: 'Weltraum',
      ocean: 'Ozeanwellen',
      city: 'Moderne Stadt',
      desert: 'Wüstendünen',
    },
    controls: {
      play: 'Abspielen',
      pause: 'Pause',
      volume: 'Lautstärke',
      mute: 'Stumm',
      unmute: 'Ton an',
      download: 'Herunterladen',
      settings: 'Einstellungen',
      fullscreen: 'Vollbild',
      exitFullscreen: 'Vollbild beenden',
    },
    membership: {
      free: 'Kostenlos: 5 Generierungen/Monat',
      vip: 'VIP 5$/Monat: 30 Generierungen',
      perMonth: '/Monat',
    },
    language: 'Sprache',
    gallery: {
      title: 'Community-Galerie',
      rentBuy: 'Mieten/Kaufen',
      creator: 'Ersteller',
      featured: 'Empfohlen',
      trending: 'Im Trend',
    },
    music: {
      title: 'Ambiente Musik',
      channels: {
        lofiChill: 'Nachtarbeit',
        synthNight: 'Synthwave',
        ambientForest: 'Regen Meditation',
      },
      favorites: 'Meine Favoriten',
      alreadyFavorited: 'Bereits in Favoriten',
      noFavorites: 'Keine Favoriten',
      volume: 'Lautstärke',
    },
    myScenes: {
      title: 'Meine Szenen',
      save: 'Aktuell speichern',
      namePlaceholder: 'Szenenname...',
      noScenes: 'Keine gespeicherten Szenen',
      cancel: 'Abbrechen',
      confirm: 'Speichern',
    },
    nft: {
      legendary: 'Legendär',
      rare: 'Selten',
      common: 'Gewöhnlich',
    },
  },
}
